#include <iostream.h> // chiamata a libreria

void main ()         // programma principale
{
  cout << "Ciao a tutti" << endl;  // istruzione di output
}

