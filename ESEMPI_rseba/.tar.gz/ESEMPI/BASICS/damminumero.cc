#include <iostream.h> // chiamata a libreria

void main ()         // programma principale
{
  int n;             // definizione di variabile
  
  cout << "Dammi un numero: ";  // istruzione di output
  cin >> n;                           // istruzione di input
  cout << "Mi hai dato il numero: " << n << endl;  // istruzione di output
  
}

